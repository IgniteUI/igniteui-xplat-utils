using System;
using System.Collections.Generic;
using System.Text;

namespace Infragistics.Samples.Shared
{
    public class SampleComponents
    {
    }
}
