console.log('index.js load');


function includeCSS() {
    console.log('index.js includeCSS');
    //var element = document.createElement("link");
    //element.setAttribute("rel", "stylesheet");
    //element.setAttribute("type", "text/css");
    //element.setAttribute("href", "css/index.css");//location of the css that we want     include for the page
    //document.getElementsByTagName("head")[0].appendChild(element);
}