function onProvideCalculator(grid, args) {

    args.setCalculator(null);

}

igRegisterScript("onProvideCalculator", onProvideCalculator, false);