

igRegisterScript("WebGridPasteOptions", (event) => {
    console.log("TODO WebGridPasteOptions");
}, false);


igRegisterScript("WebGridExcelDownload", (event) => {
    console.log("TODO WebGridExcelDownload");
}, false);

