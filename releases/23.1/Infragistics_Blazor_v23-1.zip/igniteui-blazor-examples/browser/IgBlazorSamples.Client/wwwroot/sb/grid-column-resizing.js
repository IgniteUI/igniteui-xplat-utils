

igRegisterScript("WebGridColumnResized", (event) => {
    console.log("TODO WebGridColumnResized");
}, false);

