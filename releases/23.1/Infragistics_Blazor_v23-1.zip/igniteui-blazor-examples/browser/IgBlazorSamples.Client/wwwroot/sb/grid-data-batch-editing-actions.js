
igRegisterScript("WebGridDeleteCellTemplate", (ctx) => {
    var html = window.igTemplating.html;
    // window.keyUpHandler = function () {
    //     ctx.cell.row.data[window.event.target.id] = window.event.target.value;
    // }
    return html`<div class="contact-container--edit">
 TODO
</div>`;
}, false);

igRegisterScript("WebGridAddRow", (event) => {
    console.log("TODO WebGridAddRow");
}, false);

igRegisterScript("WebGridUndo", (event) => {
    console.log("TODO WebGridUndo");
}, false);

igRegisterScript("WebGridRedo", (event) => {
    console.log("TODO WebGridRedo");
}, false);

igRegisterScript("WebGridCommit", (event) => {
    console.log("TODO WebGridCommit");
}, false);

