

igRegisterScript("WebGridUndo", (event) => {
    console.log("TODO WebGridUndo");
}, false);

igRegisterScript("WebGridRedo", (event) => {
    console.log("TODO WebGridRedo");
}, false);

igRegisterScript("WebGridCommit", (event) => {
    console.log("TODO WebGridCommit");
}, false);

