

igRegisterScript("WebGridExportEventMultiColumnHeaders", (ev) => {
    ev.detail.options.ignoreMultiColumnHeaders = false;
}, false);

