// this file contains events handlers and templates used in the razor page


