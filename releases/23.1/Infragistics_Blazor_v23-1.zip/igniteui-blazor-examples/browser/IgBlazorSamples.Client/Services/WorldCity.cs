using System;

namespace Infragistics.Samples
{
    public class WorldCity
    {
        public double Lat { get; set; }
        public double Lon { get; set; }
        public double Pop { get; set; }
        public string Country { get; set; }
        public string Name { get; set; }
        public bool Cap { get; set; }
    }
}