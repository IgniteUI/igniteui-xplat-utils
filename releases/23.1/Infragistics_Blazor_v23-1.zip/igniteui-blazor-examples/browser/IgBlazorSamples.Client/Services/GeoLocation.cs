using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Infragistics.Samples
{
    public class GeoLocation
    {
        public double Lat { get; set; }
        public double Lon { get; set; }
    }
}