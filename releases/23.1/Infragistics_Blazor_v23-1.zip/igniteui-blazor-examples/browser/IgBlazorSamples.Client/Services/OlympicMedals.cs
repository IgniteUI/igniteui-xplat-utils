using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Infragistics.Samples
{
    public class OlympicMedals
    {
        public int USA { get; set; }
        public int CHN { get; set; }
        public int RUS { get; set; }
        public string Year { get; set; }
    }
}