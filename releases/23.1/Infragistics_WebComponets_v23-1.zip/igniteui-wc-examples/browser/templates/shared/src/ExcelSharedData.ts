

export class ExcelSharedData {

}
