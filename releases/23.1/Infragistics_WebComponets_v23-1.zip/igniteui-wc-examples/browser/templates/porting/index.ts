// AutoInsertPortedSample

// new AutoInsertPortedClass();