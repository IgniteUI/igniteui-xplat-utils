
// import "./SampleFileName.css"; // optional styles only for this sample

// import { IgcLinearGaugeModule } from "igniteui-webcomponents-gauges";
// import { IgcLinearGaugeComponent } from "igniteui-webcomponents-gauges";
// import { IgcLinearGraphRangeComponent } from "igniteui-webcomponents-gauges";
// import { ModuleManager } from "igniteui-webcomponents-core";

// ModuleManager.register(IgcLinearGaugeModule);

export default class SampleFileName {

    constructor() {
    }

}
