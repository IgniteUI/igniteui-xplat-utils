/* tslint:disable */
declare module JSX {
    interface IntrinsicElements {
      "igc-dockmanager": any;
    }
  }
  /* tslint:enable */