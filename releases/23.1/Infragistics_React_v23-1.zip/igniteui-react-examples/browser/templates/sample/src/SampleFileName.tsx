import * as React from "react";
import "./SampleFileName.css"; // styles specific only to this sample

export default class SampleFileName extends React.Component<any, any> {

    public render() {
        return (
            <div className="container sample">
                <div className="options horizontal" >
                    TODO add options/editors
                </div>
                <div className="container" >
                    TODO add IG component here
                </div>
            </div>
        );
    }

    public componentDidMount() {
    }

}
